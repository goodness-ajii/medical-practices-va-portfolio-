# Medication Refill Workflow Diagram

Patient Request
↓
Verify Identity
↓
Review Medication History
↓
Send to Clinician
↓
Document Decision
↓
Update Patient
