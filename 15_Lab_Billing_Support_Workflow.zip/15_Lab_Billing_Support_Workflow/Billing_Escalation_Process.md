# Billing Escalation Process

Verify payment details.
Review account history.
Confirm applicable practice policy.
Escalate refund or billing decisions to authorized staff.
Document all communication.
Follow up with patient.
