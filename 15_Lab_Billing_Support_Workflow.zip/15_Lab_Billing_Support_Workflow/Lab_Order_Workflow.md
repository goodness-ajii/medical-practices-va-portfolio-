# Lab Order Workflow

Patient Request
↓
Identity Verification
↓
Review Lab Order Status
↓
Confirm Completion/Processing
↓
Coordinate Next Action
↓
Document Outcome
